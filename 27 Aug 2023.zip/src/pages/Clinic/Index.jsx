import React from "react";
import Layout from "../../components/Layout";
import { NavLink } from "react-router-dom";
import rowData from "../../Data";

const Index = () => {
  return (
    <>
      <Layout>
        <div className="content">
          <div className="row">
            <div className="col-sm-4 col-3">
              <h4 className="page-title">View All Clinics</h4>
            </div>
            <div className="col-sm-8 col-9 text-right m-b-20">
              <NavLink
                to={"/create-clinic"}
                className="btn btn btn-primary btn-rounded float-right"
              >
                <i className="fa fa-plus"></i> Add Clinic
              </NavLink>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              <div className="table-responsive">
                <table className="table table-border table-striped custom-table datatable mb-0">
                  <thead>
                    <tr>
                      <th>Sr No.</th>
                      <th>Cliniuc Code</th>
                      <th>Clinic Name</th>
                      <th>Parent Clinic</th>
                      <th>View</th>
                      <th>Edit</th>
                      <th>Freeze</th>
                      <th className="text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rowData.map((data, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>100{index}</td>
                        <td>{data.name}</td>
                        <td>N/A</td>
                        <td>
                          <button className="btn btn-warning">
                            <i className="fa fa-eye"></i>
                          </button>
                        </td>
                        <td>
                          <NavLink
                            to={`/edit-clinic/${index + 1}`}
                            className="btn btn-primary"
                          >
                            <i className="fa fa-pencil"></i>
                          </NavLink>
                        </td>
                        <td>
                          <button className="btn btn-danger">
                            <i className="fa fa-trash"></i>
                          </button>
                        </td>
                        <td className="text-right">
                          <div className="dropdown dropdown-action">
                            <a
                              href="#"
                              className="action-icon dropdown-toggle"
                              data-toggle="dropdown"
                              aria-expanded="false"
                            >
                              <i className="fa fa-ellipsis-v"></i>
                            </a>
                            <div className="dropdown-menu dropdown-menu-right">
                              <a
                                className="dropdown-item"
                                href="edit-patient.html"
                              >
                                <i className="fa fa-pencil m-r-5"></i> Edit
                              </a>
                              <a
                                className="dropdown-item"
                                href="#"
                                data-toggle="modal"
                                data-target="#delete_patient"
                              >
                                <i className="fa fa-trash-o m-r-5"></i> Delete
                              </a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};

export default Index;
