import { useState } from "react";

import "./App.css";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Dashboard from "./pages/Dashboard";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  BrowserRouter,
} from "react-router-dom";
import Login from "./pages/Auth/Login";
import Doctor from "./pages/Doctor";
import Clinic from "./pages/Clinic";
import Patient from "./pages/Patient";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/doctor" element={<Doctor entityType="doctor" />} />
          <Route
            path="/doctor/create"
            element={<Doctor entityType="create" />}
          />
          <Route
            path="/doctor/edit/:Id"
            element={<Doctor entityType="edit" />}
          />
          <Route path="/clinic" element={<Clinic entityType="clinic" />} />
          <Route
            path="/clinic/create"
            element={<Clinic entityType="create" />}
          />
          <Route path="/patient" element={<Patient entityType="patient" />} />
          <Route
            path="/patient/create"
            element={<Patient entityType="create" />}
          />

          {/* <Route path="/entity/:entityType" element={<Entitypage />} /> */}
          {/* <Route path="/entity/:entityType" element={<Entitypage />} /> */}
          {/* <Route path="/create-clinic" element={<CreateClinic />} /> */}
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
